//
//  myScene3.h
//  Character2
//
//  Created by compagnb on 2/27/14.
//  Copyright (c) 2014 compagnb. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface myScene3 : SKScene

@end
