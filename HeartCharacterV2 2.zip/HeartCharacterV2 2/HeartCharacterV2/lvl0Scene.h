//
//  MyScene.h
//  HeartCharacterV2
//

//  Copyright (c) 2014 compagnb. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface lvl0Scene : SKScene

@end
