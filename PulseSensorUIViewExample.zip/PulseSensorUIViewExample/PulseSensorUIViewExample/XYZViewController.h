//
//  XYZViewController.h
//  PulseSensorUIViewExample
//
//  Created by compagnb on 2/12/14.
//  Copyright (c) 2014 compagnb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZViewController : UIViewController
//Labels
@property (weak, nonatomic) IBOutlet UILabel *labelHeart;

//Buttons
- (IBAction)buttonBeatPressed:(id)sender;
- (IBAction)buttonBeat2Pressed:(id)sender;
- (IBAction)buttonProgressViewPressed:(id)sender;
//ProgressBar
@property (weak, nonatomic) IBOutlet UIProgressView *progressView1;


@end
