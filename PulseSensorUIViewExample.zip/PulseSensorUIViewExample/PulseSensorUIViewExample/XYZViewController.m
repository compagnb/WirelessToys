//
//  XYZViewController.m
//  PulseSensorUIViewExample
//
//  Created by compagnb on 2/12/14.
//  Copyright (c) 2014 compagnb. All rights reserved.
//

#import "XYZViewController.h"

@interface XYZViewController ()

@end

@implementation XYZViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"I'm In viewDidLoad");
    //[ objecName methodName : (value for type of Parameter)];
    //[self.view setBackgroundColor:[UIColor yellowColor]];
	// Do any additional setup after loading the view, typically from a nib.
    [_labelHeart setAlpha:0.5];
    // ask float 0.1
    [_progressView1 setProgress:0.2];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonBeatPressed:(id)sender {
    [_labelHeart setAlpha:1];
    [_labelHeart setTextColor:[UIColor purpleColor]];
}


- (IBAction)buttonProgressViewPressed:(id)sender {
    static float counter = 0.0;
    [_progressView1 setProgress:counter];
    counter = counter +0.1;
    NSLog(@"counter%f",counter);
    
}

- (IBAction)buttonBeat2Pressed:(id)sender {
    [_labelHeart setAlpha:0.2];
    [_labelHeart setTextColor:[UIColor lightGrayColor]];
    
}
@end
